/* ======the purpose of this c file is to help main.c in the part of the second transition on the source file=====*/

#include "assembler.h"
#define SPAICEL_BASE_LENGTH 8


/*----------------------------------------------------------------------------------------------------------------------------*/

/*this function update the empty cells in code_Pic array which reserved for the addresses of the symbols which now(at second transition) are known
 *  ,in case of error its intialize globalError to an error + write into .ext file in case of used extern variables in the assembly source file and intialize is_wrote to 'True'*/

void Update_code_Pic(union cmd_encoded code_Pic[],struct helper help_array[],int Helper_index_size,ptr head,bool *globalError_ptr,char file_name[],FILE *fp_extern,boolean *is_wrote){
    int i;
    int sent_type=-1; /*sentence_type*/
    int address;/*this variable store the address of the symbol*/
    boolean is_exist=False;/*this variable is telling us if the symbol is exist (and attached to a command sentence )in the symbol table linked list,if its value is True the symbol exist.*/
    for(i=0;i<Helper_index_size;i++){
          is_exist=SearchingSymbol(head,help_array[i].sym_name,&address,&sent_type);/*SearchingSymbbol function is intialize the variable 'address' in the address of the symbol in case its exist,and returning True,otherwise False*/
          if(is_exist){
              code_Pic[help_array[i].Location].word_other.twelve=address;
              if(sent_type==external){
                  code_Pic[help_array[i].Location].word_other.A_R_E=1;
                  if(help_array[i].Location+100>1000)
                        fprintf(fp_extern,"%s\t%d\n",help_array[i].sym_name,help_array[i].Location+100);
                  else
                        fprintf(fp_extern,"%s\t0%d\n",help_array[i].sym_name,help_array[i].Location+100);
                  *is_wrote=True;
              }

              else
                  code_Pic[help_array[i].Location].word_other.A_R_E=2;
          }
          else{
              *globalError_ptr=error;
              printf("error: the symbol-%s in line number %d at the file %s does not defined\n",help_array[i].sym_name,help_array[i].line_number,file_name);
          }
    }
}

/*----------------------------------------------------------------------------------------------------------------------*/

/*SearchingSymbbol function is intialize the variable 'address' in the address of the symbol in case its exist,and returning True,otherwise False*/

boolean SearchingSymbol(ptr head,char *sym_name,int *address_ptr,int *sent_type_ptr){
    ptr temp=head;
    while(temp!=NULL){
        if(!strcmp(sym_name,temp->sym_name) && (temp->type!=macro)){
            if(temp->type==guide || temp->type==cmd){
                *sent_type_ptr=guide;/*we need to initalize with 'guide' or 'cmd' ,its doesnt matter*/
            }
            else{
                *sent_type_ptr=external;
            }
            *address_ptr=temp->ad_value;
            return True;
        }
        temp=temp->next;
    }
    return False;
}

/*---------------------------------------------------------------------------------------------------------------------*/

/*this function is make second transition on the assembply source file in order to create .ent file ,in case of error it initialze globalError to error
 * and if there isn't any data entered to .ent file ,than is_wrote is initailize with False*/

void DealingWIthEntry(FILE *fp,FILE *fp_entry,bool *globalError_ptr,boolean *is_wrote_ptr,ptr head,int line_num,char file_name[]){
    char line_buf[MAX_LINE];/*a chars array that will store each line from the source file */
    char *ptr;
    line_num=0;
    while(!feof(fp)){
        if(!fgets(line_buf,MAX_LINE,fp))
            continue;
        line_num++;
        ptr=strtok(line_buf,"\n \t");
        if(!ptr)
            continue;
        if(isSymbol(ptr)){/*checking if its symbol,we already know its valid so we just check there is a ':' in it*/
            ptr=strtok(NULL,"\n\t ");
            if(strcmp(ptr,".entry"))
                continue;
            Writing_into(fp_entry,globalError_ptr,is_wrote_ptr,head,line_num,file_name);/*this function is extract the symbol name, and extract his address from the symbol table and write it into .ent file,in case of success its initalize is_wrote with True,
 *                                                                  in case of error ,its Initialize globalError with an error*/
            continue;
        }
        if(strcmp(ptr,".entry"))
            continue;
        Writing_into(fp_entry,globalError_ptr,is_wrote_ptr,head,line_num,file_name);
        continue;
    }
}

/*--------------------------------------------------------------------------------------------------------------------*/

/*checking if its symbol,we already know its valid so we just check there is a ':' in it*/

boolean isSymbol(char *ptr){
    while(*ptr!='\0'){
        if(*ptr==':')
            return True;
        ptr++;
    }
    return False;
}

/*--------------------------------------------------------------------------------------------------------------------*/



void Writing_into(FILE *fp_entry,bool *globalError_ptr,boolean *is_wrote_ptr,ptr head,int line_num,char file_name[]){
    char *ptr_symbol;
    int address;
    boolean is_exist=False;
    int not_for_use;/*not useble variable, I just create it for using SearchingSymbol function again*/
    ptr_symbol=strtok(NULL,"\t\n ");
    is_exist=SearchingSymbol(head,ptr_symbol,&address,&not_for_use);
    if(is_exist){
        if(address>1000)
            fprintf(fp_entry,"%s\t%d\n",ptr_symbol,address);
        else
            fprintf(fp_entry,"%s\t0%d\n",ptr_symbol,address);
        *is_wrote_ptr=True;
        return;
    }
    else{
        *globalError_ptr=error;
        printf("error: the symbol-%s that used at line number %d at the file-%s,its not declaired\n",ptr_symbol,line_num,file_name);
        return;
    }
}

/*---------------------------------------------------------------------------------------------------------------------*/

/*These print function ,prints into the .obj file in base 4, the encoding sentence that stored at code_Pic and data_Pic*/


void printAll(FILE *fp_obj,union cmd_encoded code_Pic[],int IC_LENGTH,int DC_LENGTH){
    int i;
    fprintf(fp_obj,"\t%d\t%d\n",IC_LENGTH-100,DC_LENGTH);
    for(i=100;i<IC_LENGTH;i++){
        unsigned short *x;
        unsigned short y;
        x=(unsigned short*)(&code_Pic[i-100]);
        y=*x;
        fprintf(fp_obj,"0%d\t",i);
        print2base4(fp_obj,y);
    }
}
void printAll2(FILE* fp_obj,union guide_encoded data_Pic[],int DC_LENGTH,int IC_LENGTH){
    int i;
    for(i=IC_LENGTH;i<IC_LENGTH+DC_LENGTH;i++){
        unsigned short *x;
        unsigned short y;
        x=(unsigned short*)(&data_Pic[i-IC_LENGTH]);
        y=*x;
        fprintf(fp_obj,"0%d\t",i);
        print2base4(fp_obj,y);
    }
}

void print2base4(FILE* fp_obj,unsigned short x){
    int i;
    char Base4[SPAICEL_BASE_LENGTH];
    for(i=6;i>=0;i--){
        if((x&3)==0)/*3 is '11' in binary ,so this way we isolated the 2 first bits*/
            Base4[i]='*';
        else if((x&3)==1)
            Base4[i]='#';
        else if((x&3)==2)
            Base4[i]='%';
        else
            Base4[i]='!';
        x=x>>2;
    }
    Base4[SPAICEL_BASE_LENGTH-1]='\0';/*to make it a string, I put \0 at end*/
    fprintf(fp_obj,"%s\n",Base4);

}

