#include "assembler.h"

/*Symbol_table.c stores all the functions that related to the Symnol_table linked list*/

/*----------------------------------------------------------------------------------------------------------------------*/

/*this function is buliding the symbol table acording to the parameters that are passed to it */

void Sym_Table_Builder(ptr *head_ref,char *symName,int address,sent_type type)
{
    ptr temp;
    temp=(ptr)malloc(sizeof(Symbol));
    strcpy(temp->sym_name,symName);/*coping symName which is pointing to the Symbol/Macro name to sym_name array,which suppose to keep that name. */
    temp->ad_value=address;/*Note:'address' stores the value of the macro or the address of the symbol */
    temp->type=type;/*'type' is stores the type of the Symbol/Macro */
    switch (type)
    {
    case macro:
    case cmd:
    case guide:
        temp->is_ext=not_ext;
        break; 
    case none:/*for external variable */
        temp->is_ext=external;
        break;        
    }
    Sym_Table_Connecter(temp,head_ref);/*This function is connecting the nodes of the symbol_table together*/
}

/*---------------------------------------------------------------------------------------------------------------------*/


/*this function is update all the addresses of the symbols attached to guidance sentences and add to them the value of the current IC*/
void UpdateSymboleList(ptr head,int IC){
    ptr temp=head;
    while(temp!=NULL){
        if(temp->type==guide){
            temp->ad_value+=IC;
        }
        temp=temp->next;
    }
}

/*---------------------------------------------------------------------------------------------------------------------*/
/*This function is connecting the nodes of the symbol_table together*/

void Sym_Table_Connecter(ptr temp,ptr *head_ref){
    if(*head_ref==NULL){
        
        *head_ref=temp;
        temp->next=NULL;
        return;
    }
    temp->next=*head_ref;
    *head_ref=temp;
}

/*----------------------------------------------------------------------------------------------------------------------*/

void freeList(ptr *head_ref)
{
    ptr temp;
    while(*head_ref)
    {
        temp=*head_ref;
        *head_ref=temp->next;
        free(temp);
    }
}
/*----------------------------------------------------------------------------------------------------------------------*/

/*this function is checking if a Symbol/Macro name is already exist ,if it exist it returning True ,otherwise False */

boolean isExistAlready(ptr head,char *sym_macro){
    ptr temp=head;
    while(temp!=NULL){
        if(!strcmp(temp->sym_name,sym_macro))
            return True;
        temp=temp->next;
    }
    return False;
 
}

/*---------------------------------------------------------------------------------------------------------------------*/

/*this function check if a macro which is used in a sentence is indeed defined before*,in case it is 'value_ptr' will store the value of the macro*/
boolean isExistedMacro(ptr head,char *macro_name,int* value_ptr){
    ptr temp=head;
    while(temp!=NULL){
        if((!strcmp(temp->sym_name,macro_name))&&(temp->type==macro)){
            *value_ptr=temp->ad_value;
            return True;
        }      
        temp=temp->next;    
    }
    return False;
}