/*Transition1.c is dealing with the first transition on the source file and he is dealing with parsing
 * line/sentence from the input*/



#include "assembler.h"

/*---------------------------------------------------------------------------------------------------------------------*/

/*LineParsing deal with a line from the input,it have switch inside with 21 cases for 21 saved words*/

bool LineParsing(int saved_word_num,int line_num,char file_name[],union cmd_encoded code_Pic[],union guide_encoded data_Pic[],int* IC_ptr,int *DC_ptr,ptr *head_ref,struct helper help_array[],int *Help_indexPtr,char *ptr){
    char *operName1_ptr,*operName2_ptr,*ptr_END,*ptr_START,*ptr_param,*ptr_symbol,*ptr_macro,*ptr_equal;/*operName1_ptr is going to point to the first operand in the command and operName2_ptr to the second*/
    int type_of_first_oper,type_of_sec_oper,value; /*type_of_first_oper with store the type of the first operand in the command, sec_oper stores the second type */


    switch (saved_word_num)
    {
        /*=!=!=!=!=!COMMANDS WORDS=!=!=!=!=!=!=!=!=*/
    case mov: 
    case cmp:
    case add:
    case sub:
    case lea:/*for commands with two operands */
        operName1_ptr=strtok(NULL," \t\n,");/*extracting the name of the first operand*/
        operName2_ptr=strtok(NULL," \t\n,");/*extracting the name of the second operand*/
        if(operName1_ptr==NULL || operName2_ptr==NULL){
            printf("error: you have to enter two operands exactly for the command you choosen in line %d at the file-%s\n",line_num,file_name);
            return error;
        }
        type_of_first_oper=whatType(operName1_ptr);
        type_of_sec_oper=whatType(operName2_ptr);
        if (type_of_first_oper==NONE ||type_of_sec_oper==NONE){
            error_oper(line_num,file_name);/*this function prints an error of unvalid operand*/
            return error;
        }
        if(is_excessive_text(line_num,file_name))/*checking if there is an excessive text in the sentence */
            return error;

        if(!is_Valid_Types(type_of_first_oper,type_of_sec_oper,saved_word_num,line_num,file_name))/*this function check if the types of the operands are valid for the specific command name*/
            return error;

        /*-=====encoding to first word=====*/
        code_Pic[*IC_ptr-100].mainword.opcode=saved_word_num;
        code_Pic[*IC_ptr-100].mainword.src=type_of_first_oper;
        code_Pic[*IC_ptr-100].mainword.dest=type_of_sec_oper;
        code_Pic[*IC_ptr-100].mainword.A_R_E=0;
        /*print(&code_Pic[*IC_ptr-100]);*//*###monitoring### */
        (*IC_ptr)++; /*INCREASING IC IN 1 */

         /*====encoding to rest====== */

        if(type_of_first_oper==Direct_reg && type_of_sec_oper==Direct_reg){/*if we enter this condition than both of the oparands are register and we encoding them into one word and increasing IC by 1 */
            code_Pic[*IC_ptr-100].word_reg.reg_src=reg_number(operName1_ptr);
            code_Pic[*IC_ptr-100].word_reg.reg_dest=reg_number(operName2_ptr);
            code_Pic[*IC_ptr-100].word_reg.A_R_E=0;
            /*print(&code_Pic[*IC_ptr-100]);*//*###monitoring### */
            (*IC_ptr)++;
            return no_error;/*finished to encoding the command sentence */
        }


        



        
        if(Encoding_Valid_Oper(operName1_ptr,type_of_first_oper,IC_ptr,code_Pic,head_ref,help_array,Help_indexPtr,Souce,line_num,file_name) ||
             Encoding_Valid_Oper(operName2_ptr,type_of_sec_oper,IC_ptr,code_Pic,head_ref,help_array,Help_indexPtr,Dest,line_num,file_name)){/* Encoding_Valid_Oper is checking if the operand is valid,if it is its encoding him into word or two in code_pic and increasing IC in accordance if not its returning error */
                error_oper(line_num,file_name);/*this function prints an error of unvalid operand*/
                return error;
        }

            
        break;
    case not:
    case clr:
    case inc:
    case dec:
    case jmp:
    case bne:
    case red:
    case prn:
    case jsr:/*for commands with one operand */
        operName2_ptr=strtok(NULL," \t\n,");/*extracting the name of the operand*/
        if(is_excessive_text(line_num,file_name))/*checking if there is an excessive text in the sentence */
            return error;
        type_of_sec_oper=whatType(operName2_ptr);
        if (type_of_sec_oper==NONE) {
            error_oper(line_num, file_name);/*this function prints an error of unvalid operand*/
            return error;
        }
        if(!is_Valid_Type(type_of_sec_oper,saved_word_num,line_num,file_name)) { /*this function check if the types of the operand are valid for the specific command name*/
            return error;
        }
            /*-=====encoding to first word=====*/
        code_Pic[*IC_ptr-100].mainword.opcode=saved_word_num;
        code_Pic[*IC_ptr-100].mainword.dest=type_of_sec_oper;
        code_Pic[*IC_ptr-100].mainword.A_R_E=0;
        (*IC_ptr)++;
        /*====encoding to rest====== */
        if(Encoding_Valid_Oper(operName2_ptr,type_of_sec_oper,IC_ptr,code_Pic,head_ref,help_array,Help_indexPtr,Dest,line_num,file_name)){/* Encoding_Valid_Oper is checking if the operand is valid,if it is its encoding him into word or two in code_pic and increasing IC in accordance if not its returning error */
                error_oper(line_num,file_name);/*this function prints an error of unvalid operand*/
                return error;
        }
        break;
    case rts:
    case stop:/*for commands with no operands */
        if(is_excessive_text(line_num,file_name))/*checking if there is an excessive text in the sentence */
            return error;
        code_Pic[*IC_ptr-100].mainword.opcode=saved_word_num;
        code_Pic[*IC_ptr-100].mainword.A_R_E=0;
        (*IC_ptr)++;
        break;

     /*==!=!=!=!=!=!=GUIDE  WORDS=!=!=!=!=!=!=!=!=!=*/

     case data:
        ptr_param=strtok(NULL,"\n\t ,");
         while(ptr_param){
             bool localerror1=no_error;
             bool localerror2=no_error;
            EXTRACT_VALUE_FROM_PARAMETER(ptr_param,data);/*this macro is extract the value from a parameter and initialize 'value" with the value of the paramter*/
             data_Pic[*DC_ptr].data_word.fourteen=value;
             (*DC_ptr)++;
             ptr_param=strtok(NULL,"\n\t ,");
         }

         break;

     case string:
         ptr=ptr+strlen(ptr)+1;/*ptr is skip the word '.string' and now point after it in the array 'temp'*/
         if(find_Apostrophes(ptr,&ptr_START,&ptr_END,line_num,file_name))/*this functions is finding the first " and the last " in the string and initialize ptr_SARRT to point
 *                                                                               to the first " ,and ptr_END to point to the last ,in case of an invalid input it print an error and return error value" ;*/
               return error;
         ptr=ptr_START;
         ptr++;/*skipping the first apostrophe*/
         while(ptr!=ptr_END){
             data_Pic[*DC_ptr].data_word.fourteen=*ptr;
             (*DC_ptr)++;
             ptr++;
         }
        data_Pic[*DC_ptr].data_word.fourteen=0;
        (*DC_ptr)++;


         break;

     case entry:/*in the first transition on the source file,we dont deal with '.entry.' sentence,therefor we skip to read the next sentence after checking its valid symbol and there isnt exsessive text*/

         ptr_symbol=strtok(NULL," \t\n,");/*extracting the name of the symbol*/
         if(!ptr_symbol){
             printf("you didnt entered a symbol name to the entry sentence in line number %d in the file-%s\n",line_num,file_name);
         }
         if(is_excessive_text(line_num,file_name)) { /*checking if there is an excessive text in the sentence */
             return error;
         }
         if(!is_Valid_name(ptr_symbol,1)){
             printf("you entered not valid symbol name at line number %d at the file- %s\n",line_num,file_name);
             return error;
         }
         break;



     case Extern:
         ptr_symbol=strtok(NULL," \t\n,");/*extracting the name of the symbol*/
         if(!ptr_symbol){
            printf("you didnt entered a symbol name to the extern decleration in line number %d in the file-%s\n",line_num,file_name);
         }
         if(is_excessive_text(line_num,file_name))/*checking if there is an excessive text in the sentence */
             return error;
         if(!is_Valid_name(ptr_symbol,1)){
             printf("you entered not valid symbol name at line number %d at the file- %s\n",line_num,file_name);
             return error;
         }
         if(isExistAlready(*head_ref,ptr_symbol)){
             printf("error: there is already a definition of the name of that symbol  at line number %d at the file-%s\n",line_num,file_name);
             return error;
         }
         Sym_Table_Builder(head_ref,ptr_symbol,0,none);
         break;

     case define:
         ptr_macro=strtok(NULL,"\t \n");/*extracting the macro name from the sentence*/
         ptr_equal=strtok(NULL,"\t \n");/*extracting the equal sign charactar from the sentence*/
         ptr_param=strtok(NULL,"\t \n");/*extracting the parameter from the sentence*/
         if(strtok(NULL," \t\n")) {
             printf("There is an excessive text at line number %d in the file -%s\n", line_num, file_name);
             return error;
         }
         if(!ptr_macro ||!ptr_equal ||!ptr_param){/*checking if one of the pointers is null,if it is there is missing parameter*/
             printf("you have missing text at line number %d in the file-%s\n NOTE-YOU SHOULD PUT SPACE BETWEEN ELEMENTS\n",line_num,file_name);
             return error;
         }
         if(!is_Valid_name(ptr_macro,1)){
             printf("you entered not valid macro name at line number %d at the file- %s\n",line_num,file_name);
             return error;
         }
         if(isExistAlready(*head_ref,ptr_macro)){
             printf("error: you entered a macro which is already defined in line number %d at the file-%s\n",line_num,file_name);
             return error;
         }
         if(*ptr_equal!='='){
             printf("you have unvalid character at line number %d at the file-%s\n",line_num,file_name);
             return error;
         }
         if(!is_Valid_num(ptr_param)){
             printf("error: you have to define the macro with a integer number at line number %d at the file-%s\n",line_num,file_name);
             return error;
         }
         value=atoi(ptr_param);
         Sym_Table_Builder(head_ref,ptr_macro,value,macro);
         break;


    }
    return no_error;
}
