/*=======includes====== */

#include "assembler.h"
#include "HelpingMain.h"
/*======macros======*/

#define UNVALID_SENTENCE_ERROR\
    printf("error: you entered unvalid sentence in line number %d at the file-%s\n",line_num,file_name);\
    globalError=error;\
    continue;


/*==========Main function======== */

int main(int argc,char *argv[]){
    parsing(argc,argv);/*this function is dealing with taking open the files and send them to parsing ,by 'parsingFile' function*/
    return 0;
}






void parsing(int argc,char* argv[]){
    int i;
    FILE *fp;
    if(argc==1){
        printf("you have to enter a file name as argument to main function\n");
        exit(1);
    }
    for(i=1;i<argc;i++){
        char file_name[MAX_NAME];
        if(strlen(argv[i])<MAX_LINE-3){
            strcpy(file_name,argv[i]);
            strcat(file_name,".as");
        }
        else{
            printf("the name of file %d you entered is unvalid\n",argc);
            continue;
        }        
        fp=fopen(file_name,"r");
        if(!fp){
            printf("there is a problem to open the file which is name is- %s\n",argv[i]);
            continue;
        }
        parsingFile(fp,file_name,argv[i]);/*this function is parsing the assembly source file*/
        fclose(fp);
    }
}


void parsingFile(FILE *fp,char file_name[],char *orginal_file_name){
    char line_buf[MAX_LINE];/*a chars array that will store each line from the source file */
    char temp[MAX_LINE];/*an helping array that will store the same line_buf array */
    bool globalError=no_error;
    int IC=100,DC=0,Helper_index=0;/*Helper_index is the index of the next free cell of help_array*/
    union cmd_encoded code_Pic[MAX_CELL];/*this array will store the encoded commands words,it will be the code picture */
    struct helper help_array[MAX_CELL];/*this array will store the locations (which are indexes in code_Pic array) of the missing encoded addresses words in code_Pic array;
 *                                      (there is missing words in code_pic Array because in the first transition on the assembly source file,they cant be known yet)*/
    union guide_encoded data_Pic[MAX_CELL];/*this array will store the encoded guidance words,it will be the data picture */
    int line_num=0;/*this variable counts at what line there is a problem */
    char *ptr1,*ptr2;/*this pointer helps to extract the words from the helping array 'temp' */
    ptr head=NULL;/*this ptr is pointing to the head of the symbol table which is a linked list */
    FILE *fp_extern,*fp_entry,*fp_obj;/*fp_extern is use to create an .ext file and fp_entry used to create .ent files and fp_obj usend to create a .obj file and pointing to it*/
    char file_ext[MAX_NAME],file_ent[MAX_NAME];/*these arrays store the name of the file with the endings .ext , .ent*/
    boolean is_wrote_extern=False;/*this variable store True if fp_extern point to not empty file*/
    boolean is_wrote_entry=False;
    Reset(code_Pic);/*this function reset all the bit_fields of the Code_pic array  to zero*/


    /*=!=!=!=!=!=!=FIRST TRANSITION ON THE ASSEMBLY SOURCE FILE=!=!=!=!=1=!==*/

    while(!feof(fp)){
        bool localError=no_error;
        int saved_word_num=-1;/*this variable stores the number of the saved word(there is 21 saved words 16 commands+4 guide +1 macro) */
        if(!fgets(line_buf,MAX_LINE,fp))
            continue;
        line_num++;
        strcpy(temp,line_buf);
        ptr1=strtok(temp," \t\n");/*strtok extract the first word in the sentence*/
        if(!ptr1)
            continue;
        if(*ptr1==';')/*if we encountered ; in a new line that is comment so we should continue to next line */
            continue; 
        if(strlen(ptr1)>MAX_CHARS_AS_SYMBOL){
            printf("you entered a word with too many characters at line %d at the file-%s\n",line_num,file_name);
            globalError=error;
            continue;
        }
        if(DealingWithComma(ptr1,line_buf,line_num,file_name)) { /*this function is dealing with illegal commas in the input line,in case of an error its initialize globalError to an error and print an error*/
            globalError = error;
            continue;
        }

        if(!isSavedWord(&saved_word_num,ptr1)&&!is_Valid_name(ptr1,0)){/*isSavedWord returning True if ptr1 is pointing to a saved word and store its number at 'saved_word_num',otherwise it returning False */
            globalError=error;
            printf("unvalid first name at line number %d and the file name-%s\n",line_num,file_name);
            continue;
        }
        if(saved_word_num==-1){/*if we enter this condition than there is a proper syntactic symbol name at the beginning of the sentence*/
            /*we still have to check if this symbol is not already exist,and that we do by the function isExistedAlready in the macro 'PROCESSING'*/
            PROCESSING_SAVED_WORD/*this macro is dealing with the processing of the saved word that come after the symbol name at the assembly sentence,and Depending on that saved word the macro
 *          execute operation like creating new Node in the symbol table with the symbol name and so on*/
            localError = LineParsing(saved_word_num, line_num, file_name, code_Pic, data_Pic, &IC,&DC, &head, help_array,/*LineParsing is the main parsing function to deal with 1 line from the assembly source file*/
                          &Helper_index,ptr2);
            if (localError) { /*if there is an error ,we enter this condition and update 'globalError' flag to an error;*/
                globalError = localError;
                continue;
            }
        }
        else {/*if we enter this condition than there isnt a symbol at the beggining of the sentence,there is a saved word */
            localError = LineParsing(saved_word_num, line_num, file_name, code_Pic, data_Pic, &IC,&DC, &head, help_array,/*LineParsing is the main parsing function to deal with 1 line from the assembly source file*/
                           &Helper_index,ptr1);
            if (localError) {
                globalError = localError;
                continue;
            }
        }
    }
    /*--------END OF THE FIRST TRANSITION--------*/

    if(globalError==error){/*if there is Error from the first transition we stop and continue to process the next source file*/
        freeList(&head);
        return;
    }

    /*=!=!=!=!=!=!=!=!=SECOND TRANSITION + CREATING OUTPUT FILES=!=!=!=!=!=!=*/

    fp_extern=fopen(strcat(strcpy(file_ext,orginal_file_name),".ext"),"w");/*creating a file.ext in case of no writing into it or if there  is errors in the assembly source file we delete it*/


    UpdateSymboleList(head,IC);/*this function is update all the addresses (in the symbol table linked list) of the symbols attached to guidance sentences and add to them the value of the current IC */
    Update_code_Pic(code_Pic,help_array,Helper_index,head,&globalError,file_name,fp_extern,&is_wrote_extern);/*this function update the empty cells in code_Pic array which reserved for the addresses of the symbols which now(at second transition) are known
 *                                                         ,in case of error its intialize globalError to an error + write into .ext file in case of used extern variables in the assembly source file and intialize is_wrote to 'True'*/


    fp_entry=fopen(strcat(strcpy(file_ent,orginal_file_name),".ent"),"w");/*creating a .ent file and in case of no writing into it or if there  is errors in the assembly source file we delete it*/
    rewind(fp);/*we returning fp to point to the beginning of the assembly source file*/
    DealingWIthEntry(fp,fp_entry,&globalError,&is_wrote_entry ,head,line_num,file_name);/*this function is make second transition on the assembply source file in order to create .ent file ,in case of error it initialze globalError to error and if there isn't any data entered to .ent file ,than is_wrote is initailize with False*/


    if(globalError==error || is_wrote_extern==False){/*if we enter the condition we delete the .ext file that we created*/
            remove(strcat(strcpy(file_ext,orginal_file_name),".ext"));
    }
    if(globalError==error || is_wrote_entry==False){
        remove(strcat(strcpy(file_ent,orginal_file_name),".ent"));
    }


    if(globalError!=error){
        fp_obj=fopen(strcat(strcpy(file_name,orginal_file_name),".obj"),"w");/*creating the .obj file*/
        printAll(fp_obj,code_Pic,IC,DC);
        printAll2(fp_obj,data_Pic,DC,IC);/*printing into .obj file all the encoded assembly source file*/
    }
    if(globalError!=error)
        fclose(fp_obj);
    fclose(fp_entry);
    fclose(fp_extern);
    freeList(&head);
}



