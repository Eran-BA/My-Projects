#include "assembler.h"

/*=====An helping functions for Transition1.c file ==== */

/*Helping2Transition1.c is stores some helper functions to Transition1.c which dealing with the first transition on the source file*/

/*==========ENCODING_VALID_OPER Function and some helping function for it======== */


/*this function will encode the operand into a word in code_pic array,but firstly will check it is an valid operand,if not its return an error.
 *  'Ptr_oper' pointing to the operand name,'type' can be source or destination */

bool Encoding_Valid_Oper(char *ptr_Oper,int type_of_oper,int *IC_ptr,union cmd_encoded code_Pic[],ptr *head_ref,struct helper help_array[],int *Help_indexPtr,int type,int line_num,char file_name[]){
    /* Encoding_Valid_Oper is checking if the operand is valid,if it is its encoding him into word or two in code_pic and increasing IC in accordance if not its returning error */
    int value;/*'value' will store the value is extracted from the operand,for example if the operand is 'r0' than value will store 0, if the operand is '#7' than value will store 7 and so on..*/
    bool localerror1=no_error;
    bool localerror2=no_error;
    char *ptr_symbol,*ptr;
    switch (type_of_oper)
    {
    case Immediate:/*if we enter this condition than we we will check if its an valid immediate operand, like #6, #sz etc,if its valid than we encode it. */
        if(*ptr_Oper!='#'){
            return error;
        }     
        ptr_Oper++;
        EXTRACT_VALUE_FROM_PARAMETER(ptr_Oper,0)/*this macro is extract the value of the parameter that is linked to '#' and initialized the variable 'value' in it.*/
        /*-------encoding the operand into code_Pic------- */
        code_Pic[*IC_ptr-100].word_other.twelve=value;
        code_Pic[*IC_ptr-100].word_other.A_R_E=0;
         /* print(&code_Pic[*IC_ptr-100]); */  /*##MONITORING###*/
        (*IC_ptr)++;
        break;

    case Direct:/*if we enter this condition than the operand is Direct*/
        help_array[*Help_indexPtr].Location=*IC_ptr-100;/*we are saving the spot of the cell in code_Pic(IC-100) that suppose to be encoded to address of the symbol(ptr_Oper)
 *                                                          we still dont know the address so we saving that spot in help_array and later,after the first transition we will fill that void
 *                                                          in code_Pic ,with the info in the symbol_table and with help_array*/
        strcpy(help_array[*Help_indexPtr].sym_name,ptr_Oper);
        help_array[*Help_indexPtr].line_number=line_num;
        (*Help_indexPtr)++;
        (*IC_ptr)++;
        break;

    case Fixed_index:/*this condition is for Fixed_index addressing*/
        ptr_symbol=strtok(ptr_Oper,"[");/*extracting the name of the symbol*/
        if(!is_Valid_name(ptr_symbol,1))
            return error;
        ptr=strtok(NULL,"]");/*extracting the parameter between the [],it can be a number of a macro;*/
        if(!ptr)
           return error;
        if(strtok(NULL,"\n \t")){
            return error;
        }/*checking if there is an excessive text*/
        EXTRACT_VALUE_FROM_PARAMETER(ptr,0) /*this macro extract the value from the paramter inside the [], and put it in the variable 'value'*/
        help_array[*Help_indexPtr].Location=*IC_ptr-100;
        strcpy(help_array[*Help_indexPtr].sym_name,ptr_symbol);
        help_array[*Help_indexPtr].line_number=line_num;
        (*Help_indexPtr)++;
        /*now there is a empty cell in code_Pic at index IC-100,we saved that position and that symbol in 'help_array'*/
        (*IC_ptr)++;
        code_Pic[*IC_ptr-100].word_other.twelve=value;/*encoding the next word with the value of 'value'*/
        code_Pic[*IC_ptr-100].word_other.A_R_E=0;
        (*IC_ptr)++;
        break;

    case Direct_reg:
        switch(type){
            case Dest:
                code_Pic[*IC_ptr-100].word_reg.reg_dest=reg_number(ptr_Oper);
                break;
            case Souce:
                code_Pic[*IC_ptr-100].word_reg.reg_src=reg_number(ptr_Oper);
                break;
        }
        code_Pic[*IC_ptr-100].word_reg.A_R_E=0;
        (*IC_ptr)++;
        break;    
    }
    return no_error;
}

/*helping functions for Encoding_Valid_Oper */

boolean is_Valid_num(char *ptr_num){/*checking if the operand is valid number */
    if(*ptr_num=='+' || *ptr_num=='-')
        ptr_num++;
    while(*ptr_num !='\0'){
        if(!isdigit(*ptr_num))
            return False;
        ptr_num++;    
    }
    return True;    
}

/*======================  */
