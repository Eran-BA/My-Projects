/*=====An helping functions for Transition1.c file ==== */

/*Helping3Transition1.c is stores some helper functions for Transition1.c that dealing with the first transition on the source file*/


/*=======includes====== */

#include "assembler.h"
enum{backwords,forwards};


/*----------------------------------------------------------------------------------------------------------------------*/

/*this functions is finding the first " and the last " in the string and initialize ptr_SARRT to point
 * to the first " ,and ptr_END to point to the last ,in case of an invalid input it print an error and return error value" ;*/

bool find_Apostrophes(char *ptr,char **ptrptr_START,char **ptrptr_END,int line_num,char file_name[]){
    skip_white_spaces(&ptr,forwards);/*we are skipping spaces from left to right while ptr starting position is right after the name '.string'*/
    if(*ptr!='"'){
        printf("Error: you entered unvalid string at line number %d,at the file-%s\n",line_num,file_name);
        return error;
    }
    *ptrptr_START=ptr;/*we are saving the position of the starting apostraphy*/
    skip_to_last_char(&ptr);/*this function is skiping to the last char which is '\n'*/
    ptr--;
    skip_white_spaces(&ptr,backwords);/*we are skipping spaces from the one char before last char to left*/
    if(*ptr!='"' || ptr==*ptrptr_START){
        printf("Error: you entered unvalid string at line number %d,at the file-%s\n",line_num,file_name);
        return error;
    }
    *ptrptr_END=ptr;

    return no_error;
}

/*--------------------------------------------------------------------------------------------------------------------*/



void skip_white_spaces(char **ptrptr,int direction){
    while(**ptrptr==' '|| **ptrptr =='\t'){
        if(direction==forwards)
            (*ptrptr)++;
        else
            (*ptrptr)--;
    }
}
void skip_to_last_char(char **ptrptr){
    while(**ptrptr!='\n')/*The last char at a input sentence is \n*/
        (*ptrptr)++;
}