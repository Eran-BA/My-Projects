
/*The purpose of this header file is to bind a helping functions and macros for the main c file*/
#ifndef HELPINGMAIN_H
#define HELPINGMAIN_H

#include "assembler.h"


#define PROCESSING_SAVED_WORD\
    ptr2=ptr1+strlen(ptr1)+1;\
    ptr1=strtok(ptr1,":");\
    if(isExistAlready(head,ptr1)){\
    printf("error,the symbol you entered in line number %d,at the file-%s is already defined\n",line_num,file_name);\
    globalError=error;\
    continue;\
    }\
    ptr2=strtok(ptr2," \t\n");\
    if(!ptr2){\
    UNVALID_SENTENCE_ERROR\
    }\
    if(!isSavedWord(&saved_word_num,ptr2)){\
    UNVALID_SENTENCE_ERROR\
    }\
    if(saved_word_num==entry){\
    continue;\
    }\
    else if (saved_word_num==define){\
        printf("you cant define a macro after a defintion of symnol, the error at line %d the the file-%s\n ",line_num,file_name);\
        globalError=error;\
        continue;\
    }\
    else if(saved_word_num==string || saved_word_num==data){\
    Sym_Table_Builder(&head,ptr1,DC,guide);\
    }\
    else if (saved_word_num>=mov && saved_word_num<=stop){\
    Sym_Table_Builder(&head,ptr1,IC,cmd);\
    }

#endif