/*HelpingTransition1.c is stores some helper functionswhich dealing with the first transition on the source file*/


#include "assembler.h"

/*=========Global declarations======= */
char *register_names[]={"r0","r1","r2","r3","r4","r5","r6","r7"};
char *saved_words[]={"mov","cmp","add","sub","not","clr","lea","inc","dec","jmp","bne","red","prn","jsr","rts","stop",".data",".string",".entry",".extern",".define"};


/*======An Helping functions for Tranision1.c file====== */





/*---------------------------------------------------------------------------------------------------------------------*/
/*this function reset all the bit_fields of the Code_pic array  to zero*/

void Reset(union cmd_encoded code_Pic[]){
    int i;
    for(i=0;i<MAX_CELL;i++)
        code_Pic[i].zero=0;
}



/*---------------------------------------------------------------------------------------------------------------------*/
/*this function check if threre  is excessive text at the sentence */
boolean is_excessive_text(int line_num,char file_name[]){
    if(strtok(NULL," \t\n,")){
        printf("There is an excessive text at line number %d in the file -%s\n",line_num,file_name);
        return True;
    }
    return False;
}

/*----------------------------------------------------------------------------------------------------------------------*/

/*this function print an error for unvalid operand */
void error_oper(int line_num,char file_name[]){
    printf("unvalid operand at line %d and the file-%s\n",line_num,file_name);
}


/*----------------------------------------------------------------------------------------------------------------------*/

/*this function return the the number of the register where r0 is 0 and r1 is 1 and so on,if ptr is not register name so its return -1 */
int reg_number(char *ptr){
    int i;
    for(i=0;i<NUM_OF_REG;i++){
        if(!strcmp(ptr,register_names[i]))
            return i;
    }
    return -1;
}

/*---------------------------------------------------------------------------------------------------------------------*/

/*This function returning True if ptr1 is pointing to a saved word and returning its number,otherwise it returning False */

boolean isSavedWord(int *saved_word_num,char *ptr1){
    int i;
    for(i=0;i<NUM_OF_SAVED_WORDS;i++){
        if(!strcmp(ptr1,saved_words[i])){
            *saved_word_num=i;
            return True;
        }   
    }
    return False;
}


/*----------------------------------------------------------------------------------------------------------------------*/

/*this function check if a symbol is valid or macro is valid name, x==1 for symbol that not ending with : or for name of macro*/
boolean is_Valid_name(char *ptr1,int x){
    if(!(*ptr1<='Z' && *ptr1>='A') && !(*ptr1<='z' && *ptr1>='a'))
        return False;
    while(ptr1!=ptr1+strlen(ptr1)-1){
        if(!(*ptr1<='Z' && *ptr1>='A') && !(*ptr1<='z' && *ptr1>='a') && !(*ptr1<='9' && *ptr1>='0'))
            return False;
        ptr1++;    
    }
    if(x==1){
        return True;
    }
    if(*ptr1!=':')
        return False;
    return True;       
}

/*----------------------------------------------------------------------------------------------------------------------*/

/*this function return what the type of the addressing mathod of the operand which ptr point to it */
Method whatType(char* ptr){
    char *tmp=ptr;
    int reg_num=-1;
    if(*ptr=='#')
        return Immediate;
    while(*tmp!='\0'){/*when strtok extract a word from a string ,it put a '\0' at his end,this while loop traverse all the chars in the operand */
        if(*tmp==']')
            return Fixed_index;
        tmp++;    
    } 
    reg_num=reg_number(ptr);
    if(reg_num!=-1)
        return Direct_reg;
    if(is_Valid_name(ptr,1))
        return Direct;
    return NONE;           
}
/*-----------------------------------------------------------------------------------------------------------------------*/

/*this function check if the type of the operands is valid */

boolean is_Valid_Types(int first_oper,int sec_oper,int saved_word_num,int line_num,char file_name[]){
    switch(saved_word_num){
        case mov:
        case add:
        case sub:
            if(sec_oper==Immediate){
                error_oper(line_num,file_name);
                return False;
            }
            break;
        case lea:
            if(first_oper==Immediate || first_oper==Direct_reg || sec_oper==Immediate){
                error_oper(line_num,file_name);
                return False;
            }  
    }
    return True;
}

/*---------------------------------------------------------------------------------------------------------------------*/


/*this function check if the type of the operand is valid */
boolean is_Valid_Type(int type_of_oper,int saved_word_num,int line_num,char file_name[]){
    switch(saved_word_num){
        case not:
        case clr:
        case inc:
        case dec:
        case red:
            if(type_of_oper==Immediate){
                error_oper(line_num,file_name);
                return False;
            }
            break;
        case jmp:
        case bne:
        case jsr:
            if(type_of_oper==Immediate || type_of_oper==Fixed_index){
                error_oper(line_num,file_name);
                return False;
            }
            break;

    }
    return True;
 }