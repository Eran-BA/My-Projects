/*ValidCommas.c is stores an helping functions to deal with invalid commas in a sentence, we use them when we make the first transition
 * on the source file*/


#include "assembler.h"



/*-----------------------------------------------------------------------------------------------------------------------*/

/*this function is dealing with illegal commas in the input line,in case of an error its initialize globalError to an error and print an error*/


bool DealingWithComma(char *ptr1,char line_buf[],int line_num,char file_name[]){
    bool localError=False;
    if(!strcmp(ptr1,".define"))
        localError=LegalComma1(line_buf,line_num,file_name);  /*LegalComma1 finding errors of invalid comma in the input line from type of .define ,in case of finding,it return an error*/
    else if(*(ptr1+strlen(ptr1)-1)==':')
        localError=LegalComma2(ptr1+strlen(ptr1)+1,line_num,file_name);/*if we enter this condition than we checking if there is error because of illegal commas after the first word in the line input which is a symbol */
    else
        localError=LegalComma2(line_buf,line_num,file_name); /*if we enter this condition than there isnt a symbol definition in the line input,and we checking if there is comma error from the beggining of the line */
    return localError;
}

/*----------------------------------------------------------------------------------------------------------------------*/

/*LegalComma1 finding errors of invalid comma in the input line from type of .define ,in case of finding,it return an error*/



bool LegalComma1(char *ptr,int line_num,char file_name[]){/*this function checking if there is a commas at .define phrase */
    while(*ptr!='\n'){
        if(*ptr==','){
            printf("hey! Illegal comma at line number %d in the file name-%s\n",line_num,file_name);
            return error;
        }       
        ptr++;
    }
    return no_error;      
}
/*----------------------------------------------------------------------------------------------------------------------*/

int isAfter(char *p) /*isAfter is helping function which is checking if there is any chars that are not comma or white space in the rest of storescommand[] array After the pointing of Ptr and return 1 if there is and 0 if isnt;*/
{
    while (*p != '\n')
    {
        if (*p != ' ' && *p != ',' && *p != '\t')
            return 1;
        p++;
    }
    return 0;
}

/*----------------------------------------------------------------------------------------------------------------------*/

/*LegalComma2 check if there is an illegal comma ,Multiple consecutive commas etc, if there is than its prints an error and return error,if not its return no_error*/
bool LegalComma2(char *ptr,int line_num,char file_name[]){
    int countercomma=0;
    while(*ptr==' ' || *ptr=='\t'){/*skipping white spaces*/
        ptr++;
    }
    if(*ptr==','){/*if we enter this condition than there is a comma before the first the command name in the input and that is an illegal comma*/
        printf("Illegal comma at line number %d in the file name-%s\n",line_num,file_name);
        return error;
    }
    if(*ptr!=' ' && *ptr!='\t' && *ptr!='\n'){/*if we enter this condition we encounterd the first word in the input string*/
        while(*ptr!=' ' && *ptr!='\n' && *ptr!='\t' && *ptr!=','){/*skipping the chars in the first word*/
            ptr++;
        }
    }
    while(*ptr==' ' || *ptr=='\t'){/*skipping white spaces after the first word*/
        ptr++;
    }
    if(*ptr==','){/*if we enter this condition than there is a comma after the first word in the input string and that is an illegal comma*/
        printf("Illegal comma at at line number %d in the file name-%s\n",line_num,file_name);
        return error;
    }
    /*we enter this while loop when we in the second word*/
    while(*ptr!='\n' && isAfter(ptr)){ /*we enter this condition if we not in the end of the string and there is a char after the pointing of ptr which is not white space.*/
        while(*ptr!=' ' && *ptr!='\n' && *ptr!='\t' && *ptr!=','){ /*skippping the chars in the word*/
            ptr++;
        }
        if(isAfter(ptr)){ /*if we enter this condition we are between words and not after the last word in the string*/
            while(*ptr==' ' || *ptr=='\t' || *ptr==','){/*skipping white spaces while counting the commas between the words*/
                if(*ptr==',')
                    countercomma++;
                if(countercomma==2){
                    printf("Multiple consecutive commas at line number %d in the file name-%s\n",line_num,file_name);
                    return error;
                }
                ptr++;
            }

            if(countercomma==0){
                printf("Missing comma at line number %d in the file name-%s\n",line_num,file_name);
                return error;
            }
            countercomma=0; /*initialize countercomma to zerro because we finished to be between words;*/
        }
    }
    while(*ptr!='\n'){/*when we enter this loop we are after the last word in the string*/
        while(*ptr==' ' || *ptr=='\t'){/*skipping white spaces after the first word*/
        ptr++;
        }
        if(*ptr==','){/*if we enter this condition than there is a comma after the first word in the input string and that is an illegal comma*/
            printf("Extraneous text after end of command at line number %d in the file name-%s\n",line_num,file_name);
            return error;
        }
    }
    return no_error;
}






