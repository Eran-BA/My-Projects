/*
General header file for the assembly
Contain Data structures,method declerations and Macros
======================
By Eran Ben Artzy and Ali Jabarin.
ID-204041982,311536502
====================
 */

#ifndef ASSEMBLER_H
#define ASSEMBLER_H



#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>


/*==========MACROS======== */

#define MAX_CHARS_AS_SYMBOL 32 /*The maximum chars possible for symbol including countering the char ':' at the end */
#define MAX_CELL 1000
#define NUM_OF_REG 8 /*there is 8 registers */
#define NUM_OF_SAVED_WORDS 21 /*there is 21 saved words, 16 commands+4 guides(.entry,.data..)+1 macro */
#define MAX_LINE 100
#define MAX_NAME 20 /*this is the maximum length of name of a file that is acceptable as argument to main function */

#define EXTRACT_VALUE_FROM_PARAMETER(NAME_OF_PTR,data_FLAG)\
    if(!is_Valid_num(NAME_OF_PTR)){\
        localerror1 = error;\
    }\
    if(localerror1==no_error){\
        value=atoi(NAME_OF_PTR);\
    }\
    else if(is_Valid_name(NAME_OF_PTR,1)){\
        if(!isExistedMacro(*head_ref,NAME_OF_PTR,&value))\
            localerror2=error;\
    }\
    if(localerror1==error && localerror2 == error){\
        if(data_FLAG)\
            printf("error: you entered unvalid parameter at line number %d at the file %s\n",line_num,file_name);\
        return error;\
    }





/*===========Data structures====== */

typedef enum{no_error,error}bool;
typedef enum{False,True}boolean;
typedef enum{Immediate,Direct,Fixed_index,Direct_reg,NONE}Method; /*4 types for the 4 addressing methods */
enum{mov,cmp,add,sub,not,clr,lea,inc,dec,jmp,bne,red,prn,jsr,rts,stop,data,string,entry,Extern,define};
enum{Souce=1,Dest=2};/*dest for destionation*/

struct firstword{/*this struct use to encode the first word in a command line */
    unsigned int A_R_E:2;/*for the first two bits of A.R.E */
    unsigned int dest:2; /*for the two bits thats store the Method of addressing of the destination operand */
    unsigned int src:2;/*stores the method of adreesing of the source operand */
    unsigned int opcode:4;/*stores the opcode in 4 bits */
};

struct word1{/*this struct use to encode a immediate number,adress of symbol,an index of array*/
    unsigned int A_R_E:2;/*for the first two bits of A.R.E */
    unsigned int twelve:12;/*for the 12 bits that represent an integer or address*/
};
struct word2{/*this struct use to encode a number of register */
    unsigned int A_R_E:2;/*for the first two bits of A.R.E */
    unsigned int reg_dest:3;/*for encoding the number of the register that he is a destination operand */
    unsigned int reg_src:3;/*for encoding the number of register that he is a source operand */
};
union cmd_encoded{/*this union repesent a encoded command word which can be of 3 types*/
    unsigned int zero;/*this variable helps to intialize the bitfield to all zero by initialize this variable to zero */
    struct firstword mainword; /*represent the bitfield of the first encoded word of command line */
    struct word1 word_other;/*represent the bitfield of encoded word which can store a integer,adress or index */
    struct word2 word_reg;/*represent the bitfield of a word which can store the number of the register */
};
/*------------------------------------------------------ */

struct guide_word{/*this struct represent a encoded word of a guidance line */
    unsigned int fourteen:14;/*for store a valude of integer or value of character */
};
union guide_encoded{
    unsigned int zero;/*this variable helps to intialize the bitfield to all zero by initialize this variable to zero */
    struct guide_word data_word;
};


/*------------------Linked list for symbol table----------------------------- */
typedef enum{not_ext,external}is_external;/*2 options to a symbol ,external or not external */
typedef enum{none,macro,cmd,guide}sent_type;/*3 types of sentences-command, macro, guide */
typedef struct node* ptr;
typedef struct node{
    char sym_name[MAX_CHARS_AS_SYMBOL];/*represent the symbol name */
    int ad_value;/*represent the adress of the symbol or the value of the macro*/
    sent_type type;/*represent the type of the sentence which the symbol is used */
    is_external is_ext;
    ptr next;
}Symbol;

/*---------------------Helper Struct  -----------------------
 * his purpose is to save the location of the missing coding words in Code_pic array*/

struct helper{
    char sym_name[MAX_CHARS_AS_SYMBOL];/*char array which stores the symbol name*/
    int Location;/*stores the location/indexes of the cells in code_Pic array that should be filled after the first transition*/
    int line_number;
};




/*====================FUNCTIONS PROTOTYPE======================== */


/*!+!+!+!+!+!+!+first transition function!+!+!+!+!+!+!*/

void parsing(int argc,char* argv[]);/*this function is dealing with all the source files that sent by the user */
void parsingFile(FILE *fp,char file_name[],char *orginal_file_name);/*this function parsing a specific source file */
bool LegalComma1(char *ptr,int line_num,char file_name[]);/*this function checking if there is illegal commas in the source file */
bool LegalComma2(char *ptr,int line_num,char file_name[]);
int isAfter(char *p);/*this function is helping function to isLegalComma */
bool DealingWithComma(char *ptr1,char line_buf[],int line_num,char file_name[]);
void Reset(union cmd_encoded code_Pic[]);/*this function reset all the bit_fields of the Code_pic array  to zero*/


bool Encoding_Valid_Oper(char *ptr_Oper,int type_of_oper,int *IC_ptr,union cmd_encoded code_Pic[],ptr *head_ref,struct helper help_array[],int *Help_indexPtr,int type,int line_num,char file_name[]);
boolean isSavedWord(int *saved_word_num,char *ptr1);
boolean is_Valid_name(char *ptr1,int x);/*this function check if a name of a symbol or macro is valid and returning True if it is,otherwise False*/
bool LineParsing(int saved_word_num,int line_num,char file_name[],union cmd_encoded code_Pic[],union guide_encoded data_Pic[],int* IC,int *DC,ptr *head_ref,struct helper help_array[],int *Help_indexPtr,char *ptr);

/*helping function */
boolean is_excessive_text(int line_num,char file_name[]);
int reg_number(char *ptr);
boolean is_Valid_Types(int first_oper,int sec_oper,int saved_word_num,int line_num,char file_name[]);
boolean is_Valid_Type(int type_of_oper,int saved_word_num,int line_num,char file_name[]);
void error_oper(int line_num,char file_name[]);
Method whatType(char* ptr);
bool find_Apostrophes(char *ptr,char **ptrptr_START,char **ptrptr_END,int line_num,char file_name[]);
void skip_white_spaces(char **ptrptr,int direction);
void skip_to_last_char(char **ptrptr);

boolean is_Valid_num(char *ptr_num);



/*----Symbol Tables functions---- */

void Sym_Table_Builder(ptr *head_ref,char *symName,int address,sent_type type);
void Sym_Table_Connecter(ptr temp,ptr *head_ref);
void freeList(ptr *head_ref);
boolean isExistedMacro(ptr head,char *macro_name,int* value_ptr);
boolean isExistAlready(ptr head,char *sym_macro);
void UpdateSymboleList(ptr head,int IC);


/*!+!+!+!+!+!+!second transition functions!+!+!+!+!+!+!*/

void Update_code_Pic(union cmd_encoded code_Pic[],struct helper help_array[],int Help_index,ptr head,bool *globalError_ptr,char file_name[],FILE *fp_extern,boolean *is_wrote);
boolean SearchingSymbol(ptr head,char *sym_name,int *address_ptr,int *sent_type_ptr);
void DealingWIthEntry(FILE *fp,FILE *fp_entry,bool *globalError_ptr,boolean *is_wrote_ptr,ptr head,int line_num,char file_name[]);
boolean isSymbol(char *ptr);
void Writing_into(FILE *fp_entry,bool *globalError_ptr,boolean *is_wrote_ptr,ptr head,int line_num,char file_name[]);

void printAll(FILE *fp_obj,union cmd_encoded code_Pic[],int IC_LENGTH,int DC_LENGTH);
void printAll2(FILE* fp_obj,union guide_encoded data_Pic[],int DC_LENGTH,int IC_LENGTH);
void print2base4(FILE* fp_obj,unsigned short x);


#endif