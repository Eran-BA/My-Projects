import java.io.*;

public class Files
{
    public File createFile(String fileName) throws IOException
    {
        File f = new File(fileName);
        f.createNewFile();
        return f;
    }


    public Phonebook readObject(File f) throws IOException
    {
        ObjectInputStream in = new ObjectInputStream
                (new FileInputStream(f));
        Phonebook p;
        try{
            p=(Phonebook)in.readObject();
            return p;
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch(EOFException e){}
        return null;
    }

    public void writeObject(File f,Phonebook p) throws IOException
    {
        ObjectOutputStream out = new ObjectOutputStream
                (new FileOutputStream(f));
        out.writeObject(p);
        out.close();
    }
}
